# Introducing Start-up pack
[![GitPitch](https://gitpitch.com/assets/badge.svg)](https://gitpitch.com/software-improvement-group/startup-pack/master?grs=github&t=white)
